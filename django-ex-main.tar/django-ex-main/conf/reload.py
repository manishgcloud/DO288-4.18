"""
You can set APP_CONFIG to point to this file to enable automatic reloading of
modules.
"""

reload = True
