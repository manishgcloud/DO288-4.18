This exercise has no lab files

